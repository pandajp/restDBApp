const mongoose = require('mongoose');
const _ = require('lodash');

mongoose.connect('mongodb://localhost/nodejs',{ useNewUrlParser: true });

const userSchema = new mongoose.Schema({
    email: {
        type: String
    },
    password: {
        type: String
    }
});

const User = mongoose.model('User', userSchema);

module.exports = {User}