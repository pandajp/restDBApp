const {mongo} = require('./playground/mongodb.js');
const {User} = require('./mongoose');

module.exports.saveUser = (user) => {
    return new Promise((resolve,reject)=>{
        user.save().then((result)=>{
            resolve(result);
        }).catch((err)=>{
            reject(err);
        });
    });
}

module.exports.listUser = () => {
    return new Promise((resolve,reject) => {
        User.find((err,result) => {
            if(err) {
                reject(err);
            }
            resolve(result);
        });
    });
}
