const express = require('express');
const bodyParser = require('body-parser');
const _ = require('lodash');
const {User} = require('./mongoose');

const users = require('./users');

const app = express();

//this middleware is required to retrieve request body with 
//data posted as JSON from client. the data will be available in req.body
app.use(bodyParser.json());

app.get('/users', (req,res) => {
    users.listUser().then((data) => {
        res.status(200).send(data);
    },(error) => {
        res.status(400).send({status:'FAILURE', message: error});
    });
});

app.post('/users', (req,res)=>{
    const body = _.pick(req.body, ['email','password']);
    const user = new User(body); //{email:'',password:''}

    users.saveUser(user).then((data)=>{
        res.send(data);
    }).catch((error)=>{
        res.status(400).send({status:'FAILURE', error});
    });
});

app.get('/users/me', (req, res)=>{
    res.send(req.user);
});

app.listen(3000, ()=>{
    console.log('Listening on port 3000 ...');
});