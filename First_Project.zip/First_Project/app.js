const osfunc = require('os')
const fs = require('fs')
const sum = require('./util').add
//console.log(fs.username);
fs.writeFileSync('test.txt', '1234');
//console.log(osfunc.userInfo().username);
//console.log(osfunc.userInfo().homedir);
//console.log(osfunc.userInfo().add);
console.log(sum(40,30));
