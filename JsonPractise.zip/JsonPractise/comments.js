const axios = require('axios');

const getComments= (postId) =>{
    axios.get('https://jsonplaceholder.typicode.com/posts/'+postId+'/comments')
    .then((response)=>{
        const commentStr = JSON.stringify(response.data);
        const commentArr=JSON.parse(commentStr);
        console.log('Showing '+commentArr.length+' Comments'+'(Post ID:'+postId+')\n');
        commentArr.forEach(comment => {
            console.log(comment.email + "\n"+ comment.body+'\n');
        });
    }).catch((error)=>{
        console.log(error);
    })
}

module.exports={
    comments:getComments
};