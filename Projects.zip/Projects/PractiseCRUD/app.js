//yargs
const notes=require('./note')
const yargs = require('yargs');
//console.log(yargs.argv);
const argv = yargs.
command('add', 'Add Note',{

     title:{
          describe:'Title of Note',
          alias:'t',
          type: 'string',
          demand:true
     }
}).argv;

 const command =argv._[0];
 const title =argv.title;
 const body =argv.body;

if(command =='add'){
    notes.addNote(title,body);
}else if(command == 'list'){
    const currentNotes = notes.listNotes();
    // for(const note of currentNotes){
    //     console.log(note.title);
    // }
    for(const [index,note] of currentNotes.entries()){
        console.log(index,note.title);
    }
}
  

//  console.log('command: ' +command);
//  console.log('title : ' + title);
//  console.log('body : ' + body);

// const argv = process.argv
// const command =argv[2];
// const title =argv[3];
// const body =argv[4];
// console.log('command: ' +command);
// console.log('title : ' + title);
// console.log('body : ' + body);