const somePromise = new Promise((resolve,reject)=>{

if(!true){
    resolve('Success');
}
else{

    reject('Failure');
}
});

somePromise
.then((data)=>{
    console.log('success');
})
.catch((err)=>{
console.log('failure');
});

