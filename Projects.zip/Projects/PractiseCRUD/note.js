const fs = require('fs');

let notes= [];

//module.exports = {
const addNote = (title,body) =>{
//load conternt into obj

const contStr = fs.readFileSync('notes.json');
// const contStr = fs.readFile('notes.json', (err, data)=>{
//     if(err){
//         console.log(err);
//     }
//     else{
//         console.log(data.toString());
//     }
    
// })
if(contStr!= '')
notes = JSON.parse(contStr);
//Check the title already existing

const duplicateNotes = notes.filter((note)=> title == note.title);

if(duplicateNotes!=null && duplicateNotes.length > 0)
{
console.log('Duplicate Found')
}

else{
    notes.push({title:title,body:body});
    const jsonStr = JSON.stringify(notes);
    fs.writeFileSync('notes.json',jsonStr)
}
 
    return true;
}

const listNotes = () =>{
    console.log('Listing the Nodes')
    return true;
}

const removeNote = () =>{
    return true;
}

module.exports = {
    addNote:addNote,
    listNotes:listNotes,
    remove:removeNote
}
