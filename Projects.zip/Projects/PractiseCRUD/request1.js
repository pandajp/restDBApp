getUsers=()=>{
    return new Promise((resolve,reject)=>{
        request('https://jsonplaceholder.typicode.com/users', (error,response,body)=>{
            if(error){
                console.log(error);
                reject(err);
               }
               else{
                   const status = response.statusCode;
                   if(status===200){
                       const users = JSON.parse(body);
                       for(const user of users){
                           console.log(user.name);
                           resolve(users,undefined));
                          }
                   }
               }
               
               }); 
               
            }
        // if(err)   {
            //     reject(err);
            // }
            // else{
            //     resolve([{name:'Raj'}]);
            // }
//     });

// });
// }

getUser().then(()=>{
//handle the data

})

.catch((err)=>{
//handle the error

});