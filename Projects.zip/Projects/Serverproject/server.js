const express = require('express');
const hbs = require('hbs')
const app = express();
const {check, validationResult} = require('express-validator/check')

//Rendering hbs Pages
app.set('view engine', 'hbs')
hbs.registerPartials(__dirname + '/views/partials')
hbs.registerHelper('getCurrentYear',()=>{
    return new Date();
})

//Route with Input Data  //http://localhost:3000/
app.get('/',(req,res) =>{
    res.render('index.hbs',{pageTitle : 'Welcome',
    welcomeMessage: 'Welcome to Node Server',
    currentYear: new Date().getFullYear()})
})

//Route with Input Data  //http://localhost:3000/users/1
//validation
// app.get('/users/:id',(req,res) =>{
// const userId = req.params.id;
// res.send({id:userId})})

//Route with Input Data  //http://localhost:3000/users/1
//validation
app.get('/users/:id',[
    
    check('id').isNumeric(),
    check('id').isLength(2,3)],(req,res)=>{
        const errors = validationResult(req);
        if(!errors.isEmpty()){
            return res.status(422).json({errors: errors.array()})
        }
        res.send({greeting: 'Testing'})
    }
);

app.get('/',(req, res)=> {
 //console.log('req')
// res.send('Application Started')
res.send({greeting: 'Testing'})
  });

  app.get('/users',(req, res)=> {
    //console.log('req')
// res.send('Application Started')
   res.send([{greeting: 'Testing1'},{greeting2: 'Testing2'}])
  });
//Rendering HTML Pages
//app.use(express.static(__dirname + '/public'))




//to run on server
app.listen(3000,()=>{
    console.log('listening on port 3000..')
});


