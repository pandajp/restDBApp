const express = require('express')
const app = express();
const bodyparser = require('body-parser')

app.unsubscribe(bodyparser.json())
app.get('/users', (req,res)=>{
res.status(200).send([{email:'guna@gmail.com',password:'pass123'}])
//res.status(400).send(404)
})

app.post('/users', (req,res)=>{
    console.log(req,bodyparser);
    })



//to run on server
app.listen(3000,()=>{
    console.log('listening on port 3000..')
});



