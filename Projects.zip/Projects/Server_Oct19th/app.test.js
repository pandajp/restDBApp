//const db = require('./db')
const rewire = require('rewire');
const app = require('./app')

//Explicity say use the below DB.

var db  = {

    saveUser : expect.createSpy()
}
app.__set__('db', db);

if('Should call SaveUser with user object' , () =>{

    var spy = expect.createSpy();
    spy();
    expect(spy).toHaveBeenCalled();
//     var email = 'john@example.com';
//     var password = '123abc';
// app.handleSignUp(email,password);
// expect(db.saveUser).toHaveBeenCalledWith({email,password});

});


