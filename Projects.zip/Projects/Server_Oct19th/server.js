const express = require('express');
const app = express();
const supertest = require('supertest');
const expect = require('expect');


app.get('/',(req,res) =>{
   res.status(200).send('Hello World');
    // res.status(404).send({
    //     error: 'Page Not found',
    //     name :'test App'
    //  });
    
});


module.exports={app:app}

//to run on server
app.listen(3000,()=>{
    console.log('listening on port 3000..')
});


