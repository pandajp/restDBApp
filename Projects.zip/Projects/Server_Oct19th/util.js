const db = require('./db');
module.exports.add = (a,b) =>{
return a+b;
}
//console.log(add(5,10));

module.exports.sub = (a,b) =>{
 return a-b;
 }
//console.log(sub(5,10));

module.exports.mulp = (a,b) =>{
 return a*b;
  }
//console.log(mulp(5,10));




//Synchronous testing 
     
module.exports.multiply = (a,b,callback) => {
    setTimeout(()=>{
        callback(a*b);
    },500);
 }




 module.exports.handleSignUp = (email, password) =>{
   //Check if email already avliable
    db.saveUser({email,password});
 }