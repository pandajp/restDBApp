const util = require('./util')
const expect=require('expect')
const rewire=require('rewire')
const app=require('./app')


describe('util',()=>{

    beforeEach(()=>{
   //console.log('Runing before the test cases')
    });
it('should Add 2 Numbers and return valid reult',() => {
    const result = util.add(5,10);
    expect(result).toBe(15).toBeA('number');
 });

 it('should Sub 2 Numbers and return Valid result',() => {
    const result = util.sub(5,10);
    expect(result).toBe(-5).toBeA('number');
 });

 it('should Mulp 2 Numbers and return Valid result',() => {
    const result = util.mulp(5,10);
    expect(result).toBe(50).toBeA('number');
 });

});


 //Synchronous testing  scenario
  it('should Mulp 2 Numbers and return Valid result for sunchronous call',(done)=>{
     util.multiply(5,10,(result)=>{
    expect(result).toBe(50);
    done();
 });
});


if('Should call SaveUser with user object' , () =>{
 var email = 'john@example.com';
 var password = '123abc';
app.handleSignUp(email,password);
expect(db.saveUser).toHaveBeenCalledWith({email,password});

});
 