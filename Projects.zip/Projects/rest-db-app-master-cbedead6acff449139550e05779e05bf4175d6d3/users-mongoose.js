const mongoose = require('mongoose/mongoose');


module.exports.saveUser = (user)=> {
return new Promise((resolve,reject)=>{
    user.save().then(()=>{
        return user.generateWebToken();
    }).then((token)=>{

        console.log('restarting token..');
        resolve(token);
    }).catch(e)=>{
        reject(e);
    });
});

}


module.export.listUser =()=>{
    return new Promise((resolve,reject)=>{
        user.find((err.docs)=>{
            if(err){
                reject(err);
            }
            resolve(docs);
        });
    });
}

module.exports.getUser = (email)

const authenticate = (req,res) => {
    const token = req.header('x-auth');
    User.findByToken(token).then(user)=>{
        if(!user){
            return Promise.reject();

        }
        req.user = user;
        next();
    }).catch(e)=>{
        res.status(401).send();
    });
}