const jwt = require('jsonwebtoken');

var data = {
    id: 10
}



var token  = jwt.sign(data, 'secret123');
console.log(token);

var decoded = jwt.verify(token, 'secret123');
console.log('decoded', decoded);

//http://jwt.io