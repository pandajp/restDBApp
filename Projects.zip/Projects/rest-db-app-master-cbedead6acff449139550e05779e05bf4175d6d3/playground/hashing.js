const {SHA256} = require('crypto.js');


var password = 'secret123';
var hash = SHA256(password).toString();


console.log('Message :'  +password);
console.log('Hash' +hash);



