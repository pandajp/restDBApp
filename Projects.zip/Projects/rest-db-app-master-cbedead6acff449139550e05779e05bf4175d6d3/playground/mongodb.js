const MongoClient = require('mongodb').MongoClient;

const url = 'mongodb://localhost:27017';
const dbName = 'nodejs';

module.exports.mongo = (callback) => {
    MongoClient.connect(url, {useNewUrlParser:true}, 
        (err,client)=>{
            const db = client.db(dbName);
            callback(client,db);
        });
}