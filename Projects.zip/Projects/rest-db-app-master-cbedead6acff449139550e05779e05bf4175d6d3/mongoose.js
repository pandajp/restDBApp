const mongoose = require('mongoose');
const _ = require('lodash');
const jwt = require('jsonwebtoken')
const bcrypt= require('bcryptjs')
mongoose.connect('mongodb://localhost/nodejs',{ useNewUrlParser: true });

const userSchema = new mongoose.Schema({
    email: {
        type: String,
        minlength:5
    },
    password: {
        type: String
    },
    tokens:[
        {
            access:{
                type:String,
                minlength:4
            },
            token:{
                type:String,
                minlength:6
            }
        }
    ]
});

userSchema.methods.toJSON = function(){
    const user= this;
    const userObject =user.toObject();
    return _.pick(userObject,['_id','email']);
}
userSchema.methods.generateWebToken= function(){
    const user = this;
    const access='auth';
    const token = jwt.sign({_id:user._id.toString(),access},'123abc').toString();
    user.tokens= user.tokens.concat([{access,token}]);
    return user.save().then(()=>{
        return token;
    });
}

//middleware hook for hashing password
userSchema.pre('save',function(next){
    const user= this;
    if(user.isModified('password')){
        bcrypt.genSalt(10,(err,salt)=>{
            bcrypt.hash(user.password,salt,(err,hash)=>{
                user.password=hash;
                next();
            });
        });
    }
    else{
        next();
    }
});
userSchema.statics.findByToken= function(token){
    const user= this;
    let decoded;
    try{
        decoded = jwt.verify(token,'123abc');
    }
    catch(err){
        return Promise.reject();
    }
    return User.findOne({
        '_id':decoded._id,
        'token.access':'auth',
        'tokens.token':token
    });
}

userSchema.statics.findByCredential= function(email,password){
    const user = this;
return  User.findOne({email}).then((user)=>{
    if(!user){
        return Promise.reject();
    }
return new Promise((resolve,reject)=>{
    bcrypt.compare(password,user.password,(err,res) =>{
        if(res)  {
            resolve(user);
        } else{
            reject();
        }
    });
});
});

}


const User = mongoose.model('User', userSchema);

module.exports = {User}

