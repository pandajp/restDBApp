const axios = require('axios')

const getPosts= () =>{
    axios.get('https://jsonplaceholder.typicode.com/posts?userId=1')
    .then((response)=>{
        console.log(response.data);
        const postStr = JSON.stringify(response.data);
        console.log("ID     Title");
        const postArr=JSON.parse(postStr);
        postArr.forEach(post => {
            console.log(post.id + "     "+ post.body);
        });
    }).catch((error)=>{
        console.log(error);
    })
}

module.exports={
    posts:getPosts
};