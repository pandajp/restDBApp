const post = require('./posts')
const comment = require('./comments')
const yargs= require('yargs')

const args = yargs.command('list','List notes')
                  .command('comments','retrieve the comments of the post',{
                            postId:{
                            describe:"Post Id",
                            alias:"p",
                            type: 'int',
                            demand: true
                            }
                  }).argv;
const arg=yargs.argv;
// console.log(arg);
if(arg._[0] == "posts" && arg._[1] == "list" ){
    post.posts();
} else if(arg._[0] == "comments" && arg._[1] == "list" ){
    comment.comments(arg.postId);
}
else {
    console.log('Invalid Input');
}