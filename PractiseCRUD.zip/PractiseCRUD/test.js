const display = (val) => {
    console.log(val);
}

const sum = (a,b,callback) => {
    setTimeout(()=>{
        callback(a+b);
    },500);
    
}

const diff = (a,b) => {
    display(a-b);
}


sum(10,20,(result)=>{
    console.log(result);
});
diff(10,30);

console.log('A');
setTimeout(() => {
    console.log('B');

},1000)

setTimeout(() => {
    console.log('C');

},0)

console.log('D');