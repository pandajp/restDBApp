const request = require('request');

getUsers = (callback)=> {
request('https://jsonplaceholder.typicode.com/users', (error,response,body)=>{

if(error){
 console.log(error);
 callback(error.message,undefined)
}
else{

    const status = response.statusCode;
    if(status===200){
        const users = JSON.parse(body);
        for(const user of users){
            console.log(user.name);
            callback(users,undefined)
        }
    }
}

});

}

getUsers((error,users) =>{
if(error){
    console.log(error);
}
else{
    console.log(users);
}
});
   
