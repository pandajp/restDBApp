//Practising SPY function
   //Save user function
module.exports.saveUser = (user) =>{
    console.log('Saving user to DB', user)
}