const express = require('express');
const supertest = require('supertest');
const expect = require('expect');
const app = require('./server').app;
// app.get('/', (req,res) => {
//   //  res.status(200).send('Hello World');
//   res.status(404).send({
//     error: 'Page Not found',
//     name :'test App'
//   });

// });

//to run on server


if('test case name is BDD format' , (done) =>{
    request(app).get('/').expect(200).expect('Hello world')
    .end(done);
});
